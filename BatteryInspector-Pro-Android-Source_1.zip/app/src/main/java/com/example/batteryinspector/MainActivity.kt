package com.example.batteryinspector

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

data class TelemetrySample(
    val timestamp: String,
    val powerWatt: Float,
    val tempCelsius: Float,
    val currentMa: Int
)

data class BatteryInfoState(
    val level: Int = 0,
    val chargingStatus: String = "Đang kiểm tra...",
    val pluggedType: String = "Chưa cắm sạc",
    val chargingProtocol: String = "Không xác định",
    val negotiatedMaxWattage: Double = 0.0,
    val healthStatus: String = "Không xác định",
    val estimatedHealthPercent: String = "Đang tính...",
    val cycleCount: String = "Không hỗ trợ",
    val temperatureCelsius: Float = 0f,
    val voltageMv: Int = 0,
    val currentNowMa: Int = 0,
    val realTimePowerWatt: Double = 0.0,
    val peakPowerWatt: Double = 0.0,
    val technology: String = "Li-ion",
    val chargeCounterMah: Int = 0,
    val designCapacityMah: Int = 0,
    val chargeTimeRemainingMin: Long = -1L
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF4CAF50),
                    surface = Color(0xFF1E1E24),
                    background = Color(0xFF121216)
                )
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    BatteryInspectorScreen()
                }
            }
        }
    }
}

@Composable
fun BatteryInspectorScreen() {
    val context = LocalContext.current
    var batteryInfo by remember { mutableStateOf(BatteryInfoState()) }
    var lastIntent by remember { mutableStateOf<Intent?>(null) }
    val historySamples = remember { mutableStateListOf<TelemetrySample>() }
    var peakWatt by remember { mutableDoubleStateOf(0.0) }

    DisposableEffect(context) {
        val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context, intent: Intent) {
                lastIntent = intent
                val parsed = parseBatteryInfo(ctx, intent, peakWatt)
                if (parsed.realTimePowerWatt > peakWatt) peakWatt = parsed.realTimePowerWatt
                batteryInfo = parsed.copy(peakPowerWatt = peakWatt)
            }
        }
        val initialIntent = context.registerReceiver(receiver, filter)
        if (initialIntent != null) {
            lastIntent = initialIntent
            val parsed = parseBatteryInfo(context, initialIntent, peakWatt)
            if (parsed.realTimePowerWatt > peakWatt) peakWatt = parsed.realTimePowerWatt
            batteryInfo = parsed.copy(peakPowerWatt = peakWatt)
        }
        onDispose {
            context.unregisterReceiver(receiver)
        }
    }

    // Cập nhật thông số & ghi lịch sử biểu đồ mỗi 1 giây (lưu tối đa 60 điểm = 60 giây gần nhất)
    LaunchedEffect(lastIntent) {
        val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        while (true) {
            lastIntent?.let { intent ->
                val parsed = parseBatteryInfo(context, intent, peakWatt)
                if (parsed.realTimePowerWatt > peakWatt) peakWatt = parsed.realTimePowerWatt
                batteryInfo = parsed.copy(peakPowerWatt = peakWatt)

                historySamples.add(
                    TelemetrySample(
                        timestamp = timeFmt.format(Date()),
                        powerWatt = parsed.realTimePowerWatt.toFloat(),
                        tempCelsius = parsed.temperatureCelsius,
                        currentMa = parsed.currentNowMa
                    )
                )
                if (historySamples.size > 60) {
                    historySamples.removeAt(0)
                }
            }
            delay(1000L)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                text = "Battery Inspector Pro",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(vertical = 4.dp)
            )
        }

        item {
            OverviewCard(batteryInfo)
        }

        // Biểu đồ thời gian thực: Công suất (W) & Nhiệt độ (°C)
        item {
            RealtimeChartCard(
                samples = historySamples,
                onClearHistory = {
                    historySamples.clear()
                    peakWatt = 0.0
                }
            )
        }

        item {
            SectionCard(title = "Trạng Thái & Giao Thức Sạc") {
                InfoRow("Trạng thái sạc", batteryInfo.chargingStatus)
                InfoRow("Nguồn cấp điện", batteryInfo.pluggedType)
                InfoRow("Giao thức nhận diện", batteryInfo.chargingProtocol)
                InfoRow("Công suất đỉnh ghi nhận", String.format("%.2f W", batteryInfo.peakPowerWatt))
                if (batteryInfo.negotiatedMaxWattage > 0.0) {
                    InfoRow(
                        "Công suất thương lượng tối đa",
                        String.format("%.1f W", batteryInfo.negotiatedMaxWattage)
                    )
                }
                if (batteryInfo.chargeTimeRemainingMin > 0) {
                    InfoRow("Thời gian sạc đầy dự kiến", "${batteryInfo.chargeTimeRemainingMin} phút")
                }
            }
        }

        item {
            SectionCard(title = "Sức Khoẻ Pin & Chu Kỳ Sạc") {
                InfoRow("Tình trạng phần cứng", batteryInfo.healthStatus)
                InfoRow("Số chu kỳ sạc (Cycles)", batteryInfo.cycleCount)
                InfoRow("Độ khoẻ ước tính (SoH)", batteryInfo.estimatedHealthPercent)
                InfoRow(
                    "Dung lượng thiết kế",
                    if (batteryInfo.designCapacityMah > 0) "${batteryInfo.designCapacityMah} mAh" else "Không rõ"
                )
                InfoRow(
                    "Dung lượng hiện tại trong pin",
                    if (batteryInfo.chargeCounterMah > 0) "${batteryInfo.chargeCounterMah} mAh" else "Không rõ"
                )
                InfoRow("Công nghệ lõi pin", batteryInfo.technology)
            }
        }

        item {
            SectionCard(title = "Thông Số Điện Học & Nhật Ký Dòng Sạc") {
                InfoRow("Dòng điện tức thời", "${batteryInfo.currentNowMa} mA")
                InfoRow("Điện áp pin", "${batteryInfo.voltageMv} mV")
                InfoRow("Công suất thực tế", String.format("%.2f W", batteryInfo.realTimePowerWatt))
                InfoRow("Nhiệt độ pin", "${batteryInfo.temperatureCelsius} °C")

                if (historySamples.isNotEmpty()) {
                    Divider(
                        color = Color(0xFF37474F),
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                    Text(
                        text = "5 mẫu đo gần nhất:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF81C784),
                        modifier = Modifier.padding(bottom = 4.dp)
                    )
                    historySamples.takeLast(5).reversed().forEach { s ->
                        InfoRow(
                            s.timestamp,
                            String.format("%.2f W  |  %d mA  |  %.1f°C", s.powerWatt, s.currentMa, s.tempCelsius)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RealtimeChartCard(
    samples: List<TelemetrySample>,
    onClearHistory: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Biểu Đồ Công Suất (W) & Nhiệt Độ (°C)",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF81C784)
                    )
                    Text(
                        text = "Xanh lá: Công suất (W)  •  Cam: Nhiệt độ (°C) (60s gần nhất)",
                        fontSize = 12.sp,
                        color = Color(0xFFB0BEC5)
                    )
                }
                TextButton(onClick = onClearHistory) {
                    Text("Xoá", color = Color(0xFFFF8A65), fontSize = 13.sp)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .background(Color(0xFF141418), RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                if (samples.size < 2) {
                    Text(
                        text = "Đang thu thập dữ liệu thời gian thực...",
                        color = Color(0xFF78909C),
                        fontSize = 13.sp,
                        modifier = Modifier.align(Alignment.Center)
                    )
                } else {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val width = size.width
                        val height = size.height

                        // Vẽ lưới ngang mờ
                        val gridLines = 4
                        for (i in 0..gridLines) {
                            val y = height * (i.toFloat() / gridLines)
                            drawLine(
                                color = Color(0xFF263238),
                                start = Offset(0f, y),
                                end = Offset(width, y),
                                strokeWidth = 1.dp.toPx()
                            )
                        }

                        val maxWatt = max(25f, samples.maxOf { it.powerWatt } * 1.2f)
                        val minTemp = 20f
                        val maxTemp = max(50f, samples.maxOf { it.tempCelsius } + 5f)

                        val wattPath = Path()
                        val tempPath = Path()

                        val stepX = width / (samples.size - 1).coerceAtLeast(1)

                        samples.forEachIndexed { index, sample ->
                            val x = index * stepX
                            val yWatt = height - (sample.powerWatt / maxWatt).coerceIn(0f, 1f) * height
                            val yTemp = height - ((sample.tempCelsius - minTemp) / (maxTemp - minTemp))
                                .coerceIn(0f, 1f) * height

                            if (index == 0) {
                                wattPath.moveTo(x, yWatt)
                                tempPath.moveTo(x, yTemp)
                            } else {
                                wattPath.lineTo(x, yWatt)
                                tempPath.lineTo(x, yTemp)
                            }
                        }

                        // Đường Công suất (Xanh lá)
                        drawPath(
                            path = wattPath,
                            color = Color(0xFF4CAF50),
                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                        )

                        // Đường Nhiệt độ (Cam)
                        drawPath(
                            path = tempPath,
                            color = Color(0xFFFF9800),
                            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun OverviewCard(info: BatteryInfoState) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF263238))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "${info.level}%",
                    fontSize = 44.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color(0xFF4CAF50)
                )
                Text(
                    text = info.chargingStatus,
                    fontSize = 15.sp,
                    color = Color(0xFFB0BEC5)
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = String.format("%.2f W", info.realTimePowerWatt),
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "${info.currentNowMa} mA • ${info.temperatureCelsius}°C",
                    fontSize = 14.sp,
                    color = Color(0xFFB0BEC5)
                )
            }
        }
    }
}

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF81C784),
                modifier = Modifier.padding(bottom = 10.dp)
            )
            content()
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            color = Color(0xFFB0BEC5),
            fontSize = 14.sp,
            modifier = Modifier.weight(1f)
        )
        Text(
            text = value,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

fun parseBatteryInfo(context: Context, intent: Intent, currentPeakWatt: Double): BatteryInfoState {
    val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager

    val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
    val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
    val batteryPct = if (level >= 0 && scale > 0) (level * 100) / scale else 0

    val statusInt = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
    val chargingStatus = when (statusInt) {
        BatteryManager.BATTERY_STATUS_CHARGING -> "Đang sạc (Charging)"
        BatteryManager.BATTERY_STATUS_DISCHARGING -> "Đang xả pin (Discharging)"
        BatteryManager.BATTERY_STATUS_FULL -> "Đã sạc đầy (Full)"
        BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Cắm sạc nhưng không nạp"
        else -> "Không xác định"
    }

    val pluggedInt = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
    val pluggedType = when (pluggedInt) {
        BatteryManager.BATTERY_PLUGGED_AC -> "Bộ sạc tường (AC Adapter)"
        BatteryManager.BATTERY_PLUGGED_USB -> "Cổng dữ liệu (USB Port)"
        BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Đế sạc không dây (Wireless)"
        BatteryManager.BATTERY_PLUGGED_DOCK -> "Dock sạc"
        else -> "Đang dùng pin (Chưa cắm sạc)"
    }

    val voltageMv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
    val tempTenths = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
    val temperatureCelsius = tempTenths / 10f

    val rawCurrentNow = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
    val currentNowMa = if (abs(rawCurrentNow) > 10000) rawCurrentNow / 1000 else rawCurrentNow
    val realTimePowerWatt = abs((voltageMv / 1000.0) * (currentNowMa / 1000.0))

    val rawMaxCurrent = intent.getIntExtra("max_charging_current", 0)
    val rawMaxVoltage = intent.getIntExtra("max_charging_voltage", 0)

    val maxVoltV = when {
        rawMaxVoltage > 100000 -> rawMaxVoltage / 1_000_000.0
        rawMaxVoltage > 1000 -> rawMaxVoltage / 1000.0
        else -> 0.0
    }
    val maxCurrA = when {
        rawMaxCurrent > 10000 -> rawMaxCurrent / 1_000_000.0
        rawMaxCurrent > 0 -> rawMaxCurrent / 1000.0
        else -> 0.0
    }
    val negotiatedWatt = maxVoltV * maxCurrA

    val chargingProtocol = detectChargingProtocol(
        pluggedInt = pluggedInt,
        maxVoltV = maxVoltV,
        maxCurrA = maxCurrA,
        negotiatedWatt = negotiatedWatt,
        realTimeWatt = realTimePowerWatt,
        isCharging = statusInt == BatteryManager.BATTERY_STATUS_CHARGING
    )

    val cycleFromIntent = intent.getIntExtra("android.os.extra.CYCLE_COUNT", -1)
    val cycleCountStr = when {
        cycleFromIntent >= 0 -> "$cycleFromIntent chu kỳ"
        else -> readSysFile("/sys/class/power_supply/battery/cycle_count")?.let { "$it chu kỳ" }
            ?: "Thiết bị ẩn / Cần Android 14+"
    }

    val healthInt = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)
    val healthStatus = when (healthInt) {
        BatteryManager.BATTERY_HEALTH_GOOD -> "Tốt (Good)"
        BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Quá nhiệt (Overheat)"
        BatteryManager.BATTERY_HEALTH_DEAD -> "Pin hỏng / Chai nặng (Dead)"
        BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Quá áp (Over Voltage)"
        BatteryManager.BATTERY_HEALTH_COLD -> "Quá lạnh (Cold)"
        else -> "Không xác định"
    }

    val chargeCounterUah = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER)
    val chargeCounterMah = if (chargeCounterUah > 0) chargeCounterUah / 1000 else 0
    val designCapacityMah = getDesignCapacityMah(context)

    val estimatedHealthPercent = if (chargeCounterMah > 0 && designCapacityMah > 0 && batteryPct >= 15) {
        val estimatedFullMah = (chargeCounterMah.toDouble() / batteryPct) * 100.0
        val healthPct = ((estimatedFullMah / designCapacityMah) * 100.0).roundToInt().coerceIn(1, 100)
        "$healthPct% (~${estimatedFullMah.roundToInt()} / $designCapacityMah mAh)"
    } else {
        "Cần sạc trên 15% để nội suy"
    }

    val chargeTimeRemainingMin = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
        val ms = bm.computeChargeTimeRemaining()
        if (ms > 0) ms / 60000 else -1L
    } else -1L

    val technology = intent.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "Li-ion"

    return BatteryInfoState(
        level = batteryPct,
        chargingStatus = chargingStatus,
        pluggedType = pluggedType,
        chargingProtocol = chargingProtocol,
        negotiatedMaxWattage = negotiatedWatt,
        healthStatus = healthStatus,
        estimatedHealthPercent = estimatedHealthPercent,
        cycleCount = cycleCountStr,
        temperatureCelsius = temperatureCelsius,
        voltageMv = voltageMv,
        currentNowMa = currentNowMa,
        realTimePowerWatt = realTimePowerWatt,
        peakPowerWatt = max(currentPeakWatt, realTimePowerWatt),
        technology = technology,
        chargeCounterMah = chargeCounterMah,
        designCapacityMah = designCapacityMah,
        chargeTimeRemainingMin = chargeTimeRemainingMin
    )
}

fun detectChargingProtocol(
    pluggedInt: Int,
    maxVoltV: Double,
    maxCurrA: Double,
    negotiatedWatt: Double,
    realTimeWatt: Double,
    isCharging: Boolean
): String {
    if (pluggedInt == 0) return "Không kết nối bộ sạc"
    if (pluggedInt == BatteryManager.BATTERY_PLUGGED_WIRELESS) {
        return if (negotiatedWatt >= 10.0 || realTimeWatt >= 7.5) "Sạc nhanh không dây (Fast Wireless)"
        else "Sạc không dây chuẩn Qi (5W)"
    }

    val sysUsbType = readSysFile("/sys/class/power_supply/usb/usb_type")
    if (!sysUsbType.isNullOrBlank()) {
        when {
            sysUsbType.contains("[PD_PPS]") -> return "USB Power Delivery PPS (Siêu nhanh)"
            sysUsbType.contains("[PD]") -> return "USB Power Delivery (USB-PD)"
            sysUsbType.contains("[DCP]") && maxVoltV >= 8.5 -> return "Quick Charge / Fast DCP (${maxVoltV.roundToInt()}V)"
        }
    }

    if (negotiatedWatt > 0) {
        val profileStr = String.format("(%.0fV • %.1fA)", maxVoltV, maxCurrA)
        return when {
            negotiatedWatt >= 25.0 -> "Sạc siêu nhanh PD / PPS / Proprietary $profileStr"
            maxVoltV >= 8.5 || negotiatedWatt >= 15.0 -> "Sạc nhanh (USB-PD / QC) $profileStr"
            pluggedInt == BatteryManager.BATTERY_PLUGGED_USB -> "USB tiêu chuẩn $profileStr"
            else -> "Sạc tiêu chuẩn 5V $profileStr"
        }
    }

    return when {
        isCharging && realTimeWatt >= 18.0 -> "Sạc siêu nhanh (Công suất thực cao)"
        isCharging && realTimeWatt >= 10.0 -> "Sạc nhanh đang kích hoạt"
        pluggedInt == BatteryManager.BATTERY_PLUGGED_USB -> "USB tiêu chuẩn (SDP/CDP)"
        else -> "Sạc AC tiêu chuẩn"
    }
}

@SuppressLint("PrivateApi")
fun getDesignCapacityMah(context: Context): Int {
    return try {
        val powerProfileClass = Class.forName("com.android.internal.os.PowerProfile")
        val powerProfile = powerProfileClass.getConstructor(Context::class.java).newInstance(context)
        val capacity = powerProfileClass.getMethod("getBatteryCapacity").invoke(powerProfile) as Double
        capacity.roundToInt()
    } catch (e: Exception) {
        0
    }
}

fun readSysFile(path: String): String? {
    return try {
        val file = File(path)
        if (file.exists() && file.canRead()) {
            file.bufferedReader().use { it.readLine()?.trim() }
        } else null
    } catch (e: Exception) {
        null
    }
}
