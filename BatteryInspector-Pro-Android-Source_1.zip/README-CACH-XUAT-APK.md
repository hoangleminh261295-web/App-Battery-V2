# Battery Inspector Pro (Kèm Biểu Đồ Công Suất & Nhiệt Độ Thời Gian Thực)

Dự án đã được cấu hình sẵn toàn bộ mã nguồn Android (Jetpack Compose) và script tự động đóng gói `.apk`.

## Cách 1: Tự động xuất file `.apk` trên đám mây (Không cần cài Android Studio trên máy)
1. Tạo một Repository mới trên [GitHub](https://github.com/new) và tải toàn bộ các file đã giải nén từ gói ZIP này lên.
2. Chuyển sang tab **Actions** trên GitHub -> chọn workflow **Build Android APK** -> nhấn **Run workflow**.
3. Sau khoảng 1–2 phút, tải file cài đặt **`BatteryInspectorPro-debug-apk`** (`app-debug.apk`) ngay ở mục **Artifacts** về điện thoại và cài đặt.

## Cách 2: Xuất `.apk` trực tiếp bằng Android Studio
1. Giải nén file ZIP này và mở thư mục bằng **Android Studio**.
2. Trên thanh menu, chọn **Build -> Build Bundle(s) / APK(s) -> Build APK(s)**.
3. Nhấn **Locate** để lấy file `app-debug.apk` tại `app/build/outputs/apk/debug/app-debug.apk`.
